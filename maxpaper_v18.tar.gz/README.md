# MaxPaper v18

A lightweight single-video wallpaper engine for Pop!_OS / COSMIC / Wayland.

This build keeps the working Wayland layer-shell renderer from v15, but adds an **ffmpeg optimization step** when you run `maxpaper setvideo ...`.

## What changed

- `maxpaper setvideo /absolute/path/video.mp4` now:
  - stores your original source path
  - creates a much lighter cached wallpaper video in `~/.cache/maxpaper/optimized.mp4`
  - removes audio
  - converts to **12 FPS** by default
  - downscales to a max width of **480 px** by default
  - uses a more decoder-friendly H.264 encode tuned for light playback
  - restarts the service automatically if it is already running

This is meant to be the lightest default profile yet for weak laptop hardware. Quality drops a lot, but playback should be much easier.

## Install

```bash
tar -xzf maxpaper_v16.tar.gz
cd maxpaper
./install.sh
```

## Usage

```bash
maxpaper setvideo "/home/$USER/Videos/WPR.mp4"
maxpaper restart
maxpaper status
```

## Commands

- `maxpaper setvideo /absolute/path/to/video.mp4`
- `maxpaper optimize /absolute/path/to/video.mp4`
- `maxpaper start`
- `maxpaper stop`
- `maxpaper restart`
- `maxpaper status`

## Files

- Config: `~/.config/maxpaper/config`
- Optimized cache: `~/.cache/maxpaper/optimized.mp4`
- Service: `~/.config/systemd/user/maxpaper.service`
- CLI: `/usr/local/bin/maxpaper`
- Core renderer: `/usr/local/libexec/maxpaper/maxpaper-bin`

## Optional tuning

You can change optimization settings before `setvideo`:

```bash
export MAXPAPER_OPT_WIDTH=640
export MAXPAPER_OPT_FPS=15
export MAXPAPER_OPT_CRF=35
export MAXPAPER_OPT_PRESET=medium
maxpaper setvideo "/home/$USER/Videos/WPR.mp4"
```

Lower width / higher CRF = lighter playback.

## Uninstall

```bash
cd maxpaper
./uninstall.sh
```


## Ultra-light defaults in v18

If you do nothing, `maxpaper setvideo ...` now defaults to:

- `MAXPAPER_OPT_WIDTH=480`
- `MAXPAPER_OPT_FPS=12`
- `MAXPAPER_OPT_CRF=38`
- `MAXPAPER_OPT_PRESET=medium`

You can still override them with environment variables before running `setvideo`.
